<?php
/**
* @author firesun 
* @website https://github.com/firesunCN
*/
setcookie("username");
header("Location: login.php");
exit();