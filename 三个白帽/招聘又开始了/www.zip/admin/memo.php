<?php
/**
* @author firesun 
* @website https://github.com/firesunCN
*/
require_once('header.php');
//if($_SERVER['REMOTE_ADDR']!=="127.0.0.1")
	die('<div class="alert alert-danger">我就不给你看，你来打我啊</div>');
//$result=query("select content from memo;")[0];
//echo $result["content"];
?>


	